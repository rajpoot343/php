<?php
/**
 * Created by PhpStorm.
 * User: csashokk
 * Date: 5/10/2016
 * Time: 2:37 PM
 */
$link = mysqli_connect('localhost', 'root', '', 'search');

//if (!$link) {
//  echo "Error: Unable to connect to MySQL." . PHP_EOL;
//  echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
//  echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;
//  exit;
//}


?>