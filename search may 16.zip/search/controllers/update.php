<?php
error_reporting(E_ERROR);

if(isset($_GET['eid'])){
    include_once('models/connect.php');
    $eid = $_GET['eid'];
    $sql = "SELECT * FROM website WHERE `id`='$eid'";
    $query = mysql_query($sql)or die(mysql_error());

    while($row = mysql_fetch_array($query)){
        $id = $row['id'];
        $title = $row['title'];
        $keyword = $row['meta_keyword'];
        $desc = $row['meta_description'];
        $email = $row['email'];
        $link = $row['url'];
    }
}


if(isset($_POST['submit'])){
    include_once('models/connect.php');

    $id = $_POST['id'];
    $title = $_POST['title'];
    $keyword = $_POST['keywords'];
    $desc = $_POST['description'];
    $email = $_POST['email'];
    $link = $_POST['link'];

    $sql = "UPDATE website SET `title`='$title',`meta_keyword`='$keyword',`meta_description`='$desc',`email`='$email',`url`='$link' WHERE `id`='$id'";

    $query = mysql_query($sql)or die(mysql_error());
    $num = mysql_affected_rows();
    if($num){
        $msg= '<script>alert("Data Update Successfully");</script>';
    }else{}

}

?>
