<?php
error_reporting(E_ERROR);

include_once 'models/connect.php';
$data = '';

if(isset($_GET['did'])){
    $did = $_GET['did'];

    $sql = "DELETE FROM WEBSITE WHERE id='$did'";
    $query = mysql_query($sql)or die(mysql_error());

    if($query){
        $msg= '<script>alert("Data Delete Successfully");</script>';
    }else{}

}

if(isset($_POST['q']))
    $sql = "SELECT * FROM website WHERE `title` LIKE '%".$_POST['q']."%' OR `meta_description` LIKE '%".$_POST['q']."%' OR `meta_keyword` LIKE '%".$_POST['q']."%' OR `url` LIKE '%".$_POST['q']."%'";
else
    $sql = "SELECT * FROM website";

$query = mysql_query($sql) or die(mysql_error());

while($row = mysql_fetch_array($query)){
    $data .= '<div class="result">
       <h2><a href="'.$row['url'].'">'.$row['title'].'</a></h2>
     <address>'.$row['url'].'</address>
        <p>'.$row['meta_description'].'</p>
    </div>';
}


$result_data = $data;

?>
