<?php

if(isset($_POST['submit'])){
    include_once('models/connect.php');

    $title = $_POST['title'];
    $keyword = $_POST['keywords'];
    $desc = $_POST['description'];
    $email = $_POST['email'];
    $link = $_POST['link'];

    $sql = "INSERT INTO website(`title`,`meta_keyword`,`meta_description`,`email`,`url`)VALUES('$title','$keyword','$desc','$email','$link')";

    mysql_query($sql)or die(mysql_error());
    $id = mysql_insert_id();

    if($id>0){
        $msg= '<script>alert("Data input Successfully");</script>';
    }else{}

}

?>
