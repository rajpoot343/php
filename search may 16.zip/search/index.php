<?php

$wtitle = "My Search Engine";
$name = 'Search Page';
$page = '';

if(isset($_GET['p']) && $_GET['p']=='post'){
    $page = 'post';
}else if(isset($_GET['p']) && $_GET['p']=='result'){
    $page = 'result';
}else if(isset($_GET['p']) && $_GET['p']=='details'){
    $page = 'details';
}else if(isset($_GET['p']) && $_GET['p']=='update'){
    $page = 'update';
}else{
    $page = 'home';
}
include_once 'views/'.$page.'.php';


?>
