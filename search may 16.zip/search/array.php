<?php

$data = '';
$data1 = '';
$result = '';

$arr = array(
        array("name" => "ram", "age" => 36),
        array("name" => "sham", "age" => 30),
        array('name' => "jodu", 'age' => 25),
        array('name' => "madhu", 'age' => 20)
      );

//print_r($arr);
echo json_encode($arr);
//var_dump($arr);

//echo "<br /> A. Value : ".$arr[3]['name'];
//echo "<br /> A. Value : ".$arr[3]['age'];


//for($i=0; $i<count($arr); $i++){
//    $data1 .= "<br /> Name : ".ucfirst($arr[$i]);
//}

//foreach($arr as $ar){
//    foreach($ar as $key=>$val){
//    $data1 .= "<br /> ".$key." : ".$val;
//    }
//}

//foreach($arr as $ar){
//    $data1 .= "<br /> Name : ".$ar['name'];
//    $data1 .= "<br /> Age : ".$ar['age'];
//}

for($i=0; $i<count($arr); $i++){
     $data1 .= "<br /> A. Name : ".$arr[$i]['name'];
     $data1 .= "<br /> B. Age : ".$arr[$i]['age'];
}

//
//foreach($_SERVER as $key=>$value){
//    $data .= $key."=".$value."<br />";
//}
$result = "<br />Request get : ".count($arr)." $data1 <br />";

//echo $result;

?>
