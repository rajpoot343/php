<?php

if(isset($_POST['submit'])){
    include_once('models/connect.php');

    $id = $_POST['id'];
    $title = $_POST['title'];
    $keyword = $_POST['keywords'];
    $desc = $_POST['description'];
    $email = $_POST['email'];
    $link = $_POST['link'];

    $sql = "UPDATE website SET `title`='$title',`meta_keyword`='$keyword',`meta_description`='$desc',`email`='$email',`url`='$link' WHERE `id`='$id'";

    $query = mysql_query($sql)or die(mysql_error());
    $row = mysql_num_rows($query);
    if($row>0){
        $msg= '<script>alert("Data Update Successfully");</script>';
    }else{}

}

?>
